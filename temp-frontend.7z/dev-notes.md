# Project dev notes

# Docker commands

docker build -t app-frontend .
docker run -p 3000:3000 app-frontend

# Png to ico
[pngtoicon.com](https://pngtoicon.com/)

let a  = {
  "messages": [
    {
      "To": "1000mercis@cp.assurance.returnpath.net",
      "From": "\"Darty\" <infos@contact-darty.com>",
      "Date": "01 Apr 2011 16:17:41 +0200",
      "Subject": "Cuit Vapeur 29.90 euros, Nintendo 3DS 239 euros, GPS TOM TOM 139 euros... decouvrez VITE tous les bons plans du weekend !",
      "Message-ID": "<20110401161739.E3786358A9D7B977@contact-darty.com>",
      "file_name": "20110401_1000mercis_14461469_html.msg"
    },
    {
      "To": "aamarketinginc@cp.monitor1.returnpath.net",
      "From": "MindsPay<survey@mindspaymails.com>",
      "Date": "Thu, 31 Mar 2011 23:19:52 -0500",
      "Subject": "Paid Mail : Offer #10491 get $4.00",
      "Message-ID": "<MP1301631592801EH10491@mindspay.com>",
      "file_name": "20110401_aamarketinginc_14456749_html.msg"
    },
    ]
}

let b = a["messages"]
let c = Object.keys(b[0])
