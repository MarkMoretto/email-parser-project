const ENTER_KEY = 13
const ESCAPE_KEY = 27

export { ENTER_KEY, ESCAPE_KEY }